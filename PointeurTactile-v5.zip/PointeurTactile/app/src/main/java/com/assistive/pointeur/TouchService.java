package com.assistive.pointeur;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.accessibilityservice.GestureDescription;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.hardware.input.InputManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Deux façons de produire des touchers :
 *
 * 1) MODE « SOURIS = TOUCHER » (par défaut) : une couche transparente plein écran capte les clics
 *    de la souris / du pavé tactile. À chaque clic, la couche devient traversable, un seul
 *    dispatchGesture() de 20 ms est envoyé à la position exacte du curseur, puis la couche
 *    redevient active. Maintenir = appui long de même durée, glisser = glissé, molette = défilement,
 *    clic droit = Retour.
 *
 * 2) MODE « POINTEUR VIRTUEL » : viseur + poignée, comme dans la version 1.
 *
 * Sur Android 14+ (tablette), le mode souris = toucher passe en « mode direct » : le service
 * intercepte uniquement les événements de la SOURIS (setMotionEventSources), sans couche
 * plein écran. Les doigts fonctionnent normalement et il n'y a plus de délai.
 * Sur Android < 14 et sur ChromeOS : couche de capture, activée seulement si une souris est
 * branchée (toujours active sur ChromeOS, où le pavé tactile est une souris).
 */
public class TouchService extends AccessibilityService {

    private static final long TAP_MS = 20;
    private static final long HOLD_THRESHOLD_MS = 300;   // clic maintenu au-delà : le doigt reste posé
    private static final long SEG_MS = 40;               // durée d'un segment du toucher maintenu en direct
    private static final long PINCH_MS = 220;            // durée d'un pincement (zoom)
    private static final long MAX_GESTURE_MS = 10000;
    private static final long PASS_THROUGH_DELAY_MS = 40; // le temps que la couche devienne traversable
    private static final long SCROLL_MS = 180;
    private static final int MAX_QUEUE = 20;
    private static final long LONG_PRESS_MS = 800;
    private static final long DRAG_HOLD_MS = 500;
    private static final long DRAG_MOVE_MS = 450;

    private static final int COLOR_TAP = 0xFF1E88E5;
    private static final int COLOR_LONG = 0xFFFB8C00;
    private static final int COLOR_DRAG_A = 0xFF43A047;
    private static final int COLOR_DRAG_B = 0xFFE53935;

    private enum Mode { TAP, LONG_PRESS, DRAG_START, DRAG_END }

    private WindowManager wm;
    private SharedPreferences prefs;
    private int touchSlop;
    private final Handler ui = new Handler(Looper.getMainLooper());

    // --- mode souris = toucher
    private View captureView;
    private WindowManager.LayoutParams captureLp;
    private boolean captureOn;
    private boolean captureAttached = false;
    private boolean dispatching = false;
    private boolean captureTouchable = true;
    private final java.util.ArrayDeque<GestureDescription> queue = new java.util.ArrayDeque<>();
    private boolean buttonDown;
    private float curX, curY;
    // toucher maintenu « en direct » (appui long, glisser)
    private boolean liveActive, liveWaiting, liveReleasing;
    private float liveLastX, liveLastY;
    private GestureDescription.StrokeDescription liveStroke;
    private float zoomAcc;
    private final Runnable holdTimer = () -> { if (buttonDown && !liveActive) startLive(); };
    private float downX, downY;
    private long downTime;
    private boolean moved, secondaryDown;
    private float scrollAccV, scrollAccH;
    private boolean directMode;
    private boolean isChromeOS;
    private InputManager im;
    private final InputManager.InputDeviceListener deviceListener = new InputManager.InputDeviceListener() {
        @Override public void onInputDeviceAdded(int id) { updateCaptureState(); }
        @Override public void onInputDeviceRemoved(int id) { updateCaptureState(); }
        @Override public void onInputDeviceChanged(int id) { updateCaptureState(); }
    };

    // --- pointeur virtuel
    private OverlayViews.CrossView crossView;
    private OverlayViews.CrossView markerView;
    private OverlayViews.HandleView handleView;
    private WindowManager.LayoutParams crossLp, handleLp, markerLp;
    private int crossSize, handleSize, handleGap;
    private float hotX, hotY;
    private Mode mode = Mode.TAP;
    private float dragStartX, dragStartY;
    private boolean pointerShown = false;

    // --- bouton flottant et menu
    private OverlayViews.FabView fabView;
    private LinearLayout menuView;
    private WindowManager.LayoutParams fabLp, menuLp;
    private int fabSize;
    private boolean fabAdded = false;
    private long lastMenuClose = 0;

    private final Runnable fadeFab = () -> {
        if (fabView != null) fabView.animate().alpha(0.45f).setDuration(250).start();
    };
    private final Runnable safetyRestore = this::endInjection;

    // ================================================================== cycle de vie

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        prefs = getSharedPreferences("reglages", MODE_PRIVATE);
        touchSlop = ViewConfiguration.get(this).getScaledTouchSlop();
        crossSize = dp(32);
        handleSize = dp(40);
        handleGap = dp(16);
        fabSize = dp(56);

        int[] s = screenSize();
        hotX = s[0] / 2f;
        hotY = s[1] / 2f;

        buildCaptureLayer();
        buildPointer();
        buildFab(s);

        isChromeOS = getPackageManager().hasSystemFeature("org.chromium.arc")
                || getPackageManager().hasSystemFeature("org.chromium.arc.device_management");
        captureOn = prefs.getBoolean("souris_toucher", true);
        directMode = Build.VERSION.SDK_INT >= 34
                && prefs.getBoolean("mode_direct", !isChromeOS);
        im = (InputManager) getSystemService(INPUT_SERVICE);
        im.registerInputDeviceListener(deviceListener, ui);

        if (!captureOn) showPointer();
        updateCaptureState();          // couche de capture d'abord...
        wm.addView(fabView, fabLp);    // ...puis le bouton flottant par-dessus
        fabAdded = true;
        setMode(Mode.TAP);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (wm == null) return;
        int[] s = screenSize();
        hotX = clamp(hotX, 0, s[0] - 1);
        hotY = clamp(hotY, 0, s[1] - 1);
        layoutPointer();
        if (fabView != null && fabView.isAttachedToWindow()) {
            fabLp.x = (int) clamp(fabLp.x, 0, s[0] - fabSize);
            fabLp.y = (int) clamp(fabLp.y, 0, s[1] - fabSize);
            wm.updateViewLayout(fabView, fabLp);
        }
        hideMenu();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override
    public void onInterrupt() { }

    @Override
    public void onDestroy() {
        if (im != null) im.unregisterInputDeviceListener(deviceListener);
        try { applyMotionSources(false); } catch (Exception ignored) { }
        if (wm != null) {
            hideMenu();
            detachCapture();
            hidePointer();
            removeMarker();
            if (fabView != null) { safeRemove(fabView); fabView = null; fabAdded = false; }
        }
        super.onDestroy();
    }

    // ================================================================== mode souris = toucher

    private void buildCaptureLayer() {
        captureView = new View(this);
        captureLp = overlayParams(WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT, true);
        captureView.setOnTouchListener((v, e) -> onCaptureTouch(e));
        captureView.setOnGenericMotionListener((v, e) -> onCaptureGeneric(e));
    }

    private void attachCapture() {
        if (captureAttached) return;
        captureLp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        captureTouchable = true;
        wm.addView(captureView, captureLp);
        captureAttached = true;
    }

    private void detachCapture() {
        if (!captureAttached) return;
        safeRemove(captureView);
        captureAttached = false;
    }

    private void setCaptureMode(boolean on) {
        captureOn = on;
        prefs.edit().putBoolean("souris_toucher", on).apply();
        if (on) {
            hidePointer();
            setMode(Mode.TAP);
        } else {
            showPointer();
        }
        updateCaptureState();
        bringFabToFront();
    }

    private void setDirectMode(boolean on) {
        directMode = on && Build.VERSION.SDK_INT >= 34;
        prefs.edit().putBoolean("mode_direct", directMode).apply();
        updateCaptureState();
        bringFabToFront();
    }

    /** Choisit entre mode direct, couche de capture, ou rien (pas de souris / pointeur virtuel). */
    private void updateCaptureState() {
        if (wm == null) return;
        boolean wantDirect = captureOn && directMode;
        applyMotionSources(wantDirect);
        boolean wantOverlay = captureOn && !directMode && (isChromeOS || mousePresent());
        boolean was = captureAttached;
        if (wantOverlay) attachCapture(); else detachCapture();
        if (!was && captureAttached) bringFabToFront();
    }

    private void applyMotionSources(boolean on) {
        if (Build.VERSION.SDK_INT < 34) return;
        AccessibilityServiceInfo info = getServiceInfo();
        if (info == null) return;
        int want = on ? InputDevice.SOURCE_MOUSE : 0;
        if (info.getMotionEventSources() == want) return;
        info.setMotionEventSources(want);
        setServiceInfo(info);
    }

    private boolean mousePresent() {
        if (im == null) return false;
        for (int id : im.getInputDeviceIds()) {
            InputDevice d = im.getInputDevice(id);
            if (d != null && !d.isVirtual() && d.supportsSource(InputDevice.SOURCE_MOUSE)) return true;
        }
        return false;
    }

    /** Mode direct (Android 14+) : reçoit uniquement les événements de la souris. */
    @Override
    public void onMotionEvent(MotionEvent e) {
        if (!captureOn || !directMode) return;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                handleDown(e.getX(), e.getY(),
                        (e.getButtonState() & MotionEvent.BUTTON_SECONDARY) != 0, e.getEventTime());
                break;
            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < e.getHistorySize(); i++) {
                    handleMove(e.getHistoricalX(i), e.getHistoricalY(i));
                }
                handleMove(e.getX(), e.getY());
                break;
            case MotionEvent.ACTION_UP:
                handleUp(e.getX(), e.getY(), e.getEventTime());
                break;
            case MotionEvent.ACTION_CANCEL:
                handleCancel();
                break;
            case MotionEvent.ACTION_SCROLL:
                handleScroll(e.getX(), e.getY(),
                        e.getAxisValue(MotionEvent.AXIS_VSCROLL), e.getAxisValue(MotionEvent.AXIS_HSCROLL));
                break;
            default:
                break;
        }
    }

    /** Couche de capture : convertit les coordonnées puis délègue aux gestionnaires communs. */
    private boolean onCaptureTouch(MotionEvent e) {
        float ox = e.getRawX() - e.getX();   // décalage vue -> écran
        float oy = e.getRawY() - e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                handleDown(e.getRawX(), e.getRawY(),
                        (e.getButtonState() & MotionEvent.BUTTON_SECONDARY) != 0, e.getEventTime());
                return true;
            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < e.getHistorySize(); i++) {
                    handleMove(e.getHistoricalX(i) + ox, e.getHistoricalY(i) + oy);
                }
                handleMove(e.getRawX(), e.getRawY());
                return true;
            case MotionEvent.ACTION_UP:
                handleUp(e.getRawX(), e.getRawY(), e.getEventTime());
                return true;
            case MotionEvent.ACTION_CANCEL:
                handleCancel();
                return true;
            default:
                return true;
        }
    }

    private boolean onCaptureGeneric(MotionEvent e) {
        if (e.getActionMasked() != MotionEvent.ACTION_SCROLL) return false;
        handleScroll(e.getRawX(), e.getRawY(),
                e.getAxisValue(MotionEvent.AXIS_VSCROLL), e.getAxisValue(MotionEvent.AXIS_HSCROLL));
        return true;
    }

    // --- gestionnaires communs (coordonnées écran)
    //
    // Clic court            -> 1 toucher de 20 ms.
    // Clic gauche maintenu  -> le doigt virtuel se pose après 300 ms et RESTE posé tant que le
    //                          bouton est enfoncé (vrai appui long, en direct).
    // Cliquer-glisser       -> le doigt virtuel suit la souris en direct jusqu'au relâchement.
    // Molette               -> pincement à deux doigts centré sur le curseur (zoom / dézoom).
    // Clic droit            -> Retour.

    private void handleDown(float x, float y, boolean secondary, long time) {
        if (secondary) {
            secondaryDown = true;
            buttonDown = false;
            return;
        }
        secondaryDown = false;
        buttonDown = true;
        downX = curX = x;
        downY = curY = y;
        downTime = time;
        moved = false;
        ui.removeCallbacks(holdTimer);
        ui.postDelayed(holdTimer, HOLD_THRESHOLD_MS);
    }

    private void handleMove(float x, float y) {
        if (!buttonDown) return;
        curX = x;
        curY = y;
        if (!moved && Math.hypot(x - downX, y - downY) > touchSlop) {
            moved = true;
            if (!liveActive) startLive();     // glisser : le doigt suit la souris en direct
        }
    }

    private void handleUp(float x, float y, long time) {
        ui.removeCallbacks(holdTimer);
        if (secondaryDown) {
            secondaryDown = false;
            performGlobalAction(GLOBAL_ACTION_BACK);
            return;
        }
        if (!buttonDown) return;
        buttonDown = false;
        curX = x;
        curY = y;
        if (liveActive) {
            liveReleasing = true;              // le doigt se relève au prochain segment
        } else {
            Path p = new Path();               // clic court : 1 clic = 1 toucher de 20 ms
            p.moveTo(pos(downX), pos(downY));
            inject(single(p, TAP_MS));
        }
    }

    private void handleCancel() {
        ui.removeCallbacks(holdTimer);
        secondaryDown = false;
        buttonDown = false;
        if (liveActive) liveReleasing = true;
    }

    // --- toucher maintenu en direct (chaîne de segments continueStroke)

    private void startLive() {
        liveActive = true;
        liveReleasing = false;
        if (dispatching) { liveWaiting = true; return; }   // démarre dès que la file est vide
        beginLive();
    }

    private void beginLive() {
        liveWaiting = false;
        dispatching = true;
        ui.removeCallbacks(safetyRestore);
        liveLastX = pos(downX);
        liveLastY = pos(downY);
        Path p = new Path();
        p.moveTo(liveLastX, liveLastY);
        liveStroke = new GestureDescription.StrokeDescription(p, 0, SEG_MS, true);
        if (captureAttached && captureTouchable) {
            setCaptureTouchable(false);
            ui.postDelayed(() -> dispatchLive(liveStroke), PASS_THROUGH_DELAY_MS);
        } else {
            dispatchLive(liveStroke);
        }
    }

    private void dispatchLive(GestureDescription.StrokeDescription stroke) {
        GestureDescription g = new GestureDescription.Builder().addStroke(stroke).build();
        boolean ok = dispatchGesture(g, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription d) {
                if (stroke.willContinue()) ui.post(TouchService.this::nextLive);
                else ui.post(TouchService.this::endLive);
            }
            @Override public void onCancelled(GestureDescription d) { ui.post(TouchService.this::endLive); }
        }, null);
        if (!ok) endLive();
    }

    private void nextLive() {
        if (!liveActive) return;
        float tx = pos(curX), ty = pos(curY);
        Path p = new Path();
        p.moveTo(liveLastX, liveLastY);
        if (tx != liveLastX || ty != liveLastY) p.lineTo(tx, ty);
        boolean last = liveReleasing;
        liveStroke = liveStroke.continueStroke(p, 0, last ? 16 : SEG_MS, !last);
        liveLastX = tx;
        liveLastY = ty;
        dispatchLive(liveStroke);
    }

    private void endLive() {
        liveActive = false;
        liveReleasing = false;
        liveWaiting = false;
        liveStroke = null;
        startNext();
    }

    /** Molette -> pincement à deux doigts centré sur le curseur : vers le haut = zoom, vers le bas = dézoom. */
    private void handleScroll(float rx, float ry, float v, float h) {
        zoomAcc += v;
        if (dispatching) return;                            // on cumule pendant un geste en cours
        if (Math.abs(zoomAcc) < 1f) return;
        float notches = clamp(zoomAcc, -4f, 4f);
        zoomAcc = 0;

        int[] s = screenSize();
        float small = dp(40);                               // écart minimal d'un doigt au centre
        float big = small + dp(70) * Math.abs(notches);     // chaque cran = environ 70 dp d'écart en plus
        float maxR = Math.max(small + dp(10), Math.min(big, s[0] / 2f - 2));
        float cx = clamp(rx, maxR + 1, s[0] - maxR - 2);
        float cy = clamp(ry, 1, s[1] - 2);
        float from = notches > 0 ? small : maxR;            // zoom : les doigts s'écartent
        float to   = notches > 0 ? maxR : small;            // dézoom : les doigts se rapprochent

        Path left = new Path();
        left.moveTo(cx - from, cy);
        left.lineTo(cx - to, cy);
        Path right = new Path();
        right.moveTo(cx + from, cy);
        right.lineTo(cx + to, cy);
        inject(new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(left, 0, PINCH_MS))
                .addStroke(new GestureDescription.StrokeDescription(right, 0, PINCH_MS))
                .build());
    }

    /**
     * File d'attente des gestes : chaque clic est conservé et envoyé dans l'ordre,
     * jamais ignoré, même si les clics arrivent plus vite que les touchers ne se terminent.
     */
    private void inject(GestureDescription g) {
        if (queue.size() >= MAX_QUEUE) queue.pollFirst();   // garde-fou : on ne laisse pas la file exploser
        queue.addLast(g);
        if (!dispatching) startNext();
    }

    private void startNext() {
        ui.removeCallbacks(safetyRestore);
        GestureDescription g = queue.pollFirst();
        if (g == null) {
            dispatching = false;
            if (liveWaiting) { beginLive(); return; }
            if (captureOn) setCaptureTouchable(true);
            return;
        }
        dispatching = true;
        if (captureAttached && captureTouchable) {
            // La couche doit être traversable avant que le toucher injecté ne commence.
            setCaptureTouchable(false);
            ui.postDelayed(() -> send(g), PASS_THROUGH_DELAY_MS);
        } else {
            send(g);   // mode direct, ou couche déjà traversable : envoi immédiat
        }
    }

    private void send(GestureDescription g) {
        boolean ok = dispatchGesture(g, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription d) { ui.post(TouchService.this::startNext); }
            @Override public void onCancelled(GestureDescription d) { ui.post(TouchService.this::startNext); }
        }, null);
        if (!ok) {
            if (directMode && captureOn) {
                // Sécurité : si le mode direct ne marche pas sur cet appareil, on revient à la couche.
                queue.clear();
                dispatching = false;
                setDirectMode(false);
                Toast.makeText(this, "Mode direct indisponible : passage au mode couche",
                        Toast.LENGTH_LONG).show();
                return;
            }
            startNext();
            return;
        }
        ui.postDelayed(safetyRestore, MAX_GESTURE_MS + 2000);
    }

    /** Filet de sécurité si le système ne rappelle jamais : on vide la file et on réactive la couche. */
    private void endInjection() {
        queue.clear();
        dispatching = false;
        liveActive = liveWaiting = liveReleasing = false;
        if (captureOn) setCaptureTouchable(true);
    }

    private void setCaptureTouchable(boolean touchable) {
        if (!captureAttached || captureTouchable == touchable) return;
        captureTouchable = touchable;
        if (touchable) captureLp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        else captureLp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        wm.updateViewLayout(captureView, captureLp);
    }

    private static GestureDescription single(Path p, long durationMs) {
        return new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(p, 0, durationMs))
                .build();
    }

    private static float pos(float v) { return Math.max(0f, v); }

    // ================================================================== pointeur virtuel

    private void buildPointer() {
        crossView = new OverlayViews.CrossView(this, COLOR_TAP);
        crossLp = overlayParams(crossSize, crossSize, false);
        handleView = new OverlayViews.HandleView(this);
        handleLp = overlayParams(handleSize, handleSize, true);
        handleView.setOnTouchListener(new DragClick() {
            float startX, startY;
            @Override void onStart() { startX = hotX; startY = hotY; }
            @Override void onDrag(float dx, float dy) {
                int[] sz = screenSize();
                hotX = clamp(startX + dx, 0, sz[0] - 1);
                hotY = clamp(startY + dy, 0, sz[1] - 1);
                layoutPointer();
            }
            @Override void onClick() { pointerClick(); }
        });
    }

    private void pointerClick() {
        float[] p = hotspotOnScreen();
        float x = p[0], y = p[1];
        switch (mode) {
            case TAP:
                press(x, y, TAP_MS);
                break;
            case LONG_PRESS:
                press(x, y, LONG_PRESS_MS);
                setMode(Mode.TAP);
                break;
            case DRAG_START:
                dragStartX = x;
                dragStartY = y;
                showMarker();
                setMode(Mode.DRAG_END);
                break;
            case DRAG_END:
                drag(dragStartX, dragStartY, x, y);
                setMode(Mode.TAP);
                break;
        }
    }

    private void press(float x, float y, long durationMs) {
        Path path = new Path();
        path.moveTo(pos(x), pos(y));
        dispatchGesture(single(path, durationMs), null, null);
        if (crossView != null) crossView.flash();
    }

    private void drag(float sx, float sy, float ex, float ey) {
        sx = pos(sx); sy = pos(sy); ex = pos(ex); ey = pos(ey);
        Path hold = new Path();
        hold.moveTo(sx, sy);
        final GestureDescription.StrokeDescription first =
                new GestureDescription.StrokeDescription(hold, 0, DRAG_HOLD_MS, true);
        Path move = new Path();
        move.moveTo(sx, sy);
        move.lineTo(ex, ey);
        final GestureDescription.StrokeDescription second =
                first.continueStroke(move, 0, DRAG_MOVE_MS, false);
        dispatchGesture(new GestureDescription.Builder().addStroke(first).build(),
                new GestureResultCallback() {
                    @Override
                    public void onCompleted(GestureDescription gestureDescription) {
                        dispatchGesture(new GestureDescription.Builder().addStroke(second).build(),
                                null, null);
                    }
                }, null);
        if (crossView != null) crossView.flash();
    }

    private float[] hotspotOnScreen() {
        if (crossView != null && pointerShown && crossView.getWidth() > 0) {
            int[] loc = new int[2];
            crossView.getLocationOnScreen(loc);
            return new float[]{loc[0] + crossView.getWidth() / 2f, loc[1] + crossView.getHeight() / 2f};
        }
        return new float[]{hotX, hotY};
    }

    private void setMode(Mode m) {
        mode = m;
        if (m != Mode.DRAG_END) removeMarker();
        int color;
        String label;
        switch (m) {
            case LONG_PRESS: color = COLOR_LONG;   label = "long"; break;
            case DRAG_START: color = COLOR_DRAG_A; label = "A";    break;
            case DRAG_END:   color = COLOR_DRAG_B; label = "B";    break;
            default:         color = COLOR_TAP;    label = "1:1";  break;
        }
        if (handleView != null) handleView.setStyle(color, label);
        if (crossView != null) crossView.setColor(color);
    }

    private void layoutPointer() {
        int[] s = screenSize();
        crossLp.x = Math.round(hotX - crossSize / 2f);
        crossLp.y = Math.round(hotY - crossSize / 2f);
        int hx = Math.round(hotX) + handleGap;
        int hy = Math.round(hotY) + handleGap;
        if (hx + handleSize > s[0]) hx = Math.round(hotX) - handleGap - handleSize;
        if (hy + handleSize > s[1]) hy = Math.round(hotY) - handleGap - handleSize;
        handleLp.x = hx;
        handleLp.y = hy;
        if (pointerShown) {
            wm.updateViewLayout(crossView, crossLp);
            wm.updateViewLayout(handleView, handleLp);
        }
    }

    private void showPointer() {
        if (pointerShown) return;
        layoutPointer();
        wm.addView(crossView, crossLp);
        wm.addView(handleView, handleLp);
        pointerShown = true;
    }

    private void hidePointer() {
        if (!pointerShown) return;
        safeRemove(crossView);
        safeRemove(handleView);
        pointerShown = false;
    }

    private void recenterPointer() {
        int[] s = screenSize();
        hotX = s[0] / 2f;
        hotY = s[1] / 2f;
        if (pointerShown) layoutPointer(); else showPointer();
        bringFabToFront();
    }

    private void showMarker() {
        removeMarker();
        markerView = new OverlayViews.CrossView(this, COLOR_DRAG_A);
        markerLp = overlayParams(crossSize, crossSize, false);
        markerLp.x = Math.round(hotX - crossSize / 2f);
        markerLp.y = Math.round(hotY - crossSize / 2f);
        wm.addView(markerView, markerLp);
    }

    private void removeMarker() {
        if (markerView != null) {
            safeRemove(markerView);
            markerView = null;
        }
    }

    // ================================================================== bouton flottant

    private void buildFab(int[] s) {
        fabView = new OverlayViews.FabView(this);
        fabLp = overlayParams(fabSize, fabSize, true);
        fabLp.x = s[0] - fabSize - dp(16);
        fabLp.y = s[1] / 3;
        fabView.setAlpha(0.45f);
        fabView.setOnTouchListener(new DragClick() {
            int startX, startY;
            @Override void onStart() {
                ui.removeCallbacks(fadeFab);
                fabView.animate().cancel();
                fabView.setAlpha(1f);
                startX = fabLp.x;
                startY = fabLp.y;
            }
            @Override void onDrag(float dx, float dy) {
                hideMenu();
                int[] sz = screenSize();
                fabLp.x = (int) clamp(startX + dx, 0, sz[0] - fabSize);
                fabLp.y = (int) clamp(startY + dy, 0, sz[1] - fabSize);
                wm.updateViewLayout(fabView, fabLp);
            }
            @Override void onClick() { toggleMenu(); }
            @Override void onEnd() { ui.postDelayed(fadeFab, 1500); }
        });
    }

    /** Le bouton flottant doit toujours rester au-dessus de la couche de capture. */
    private void bringFabToFront() {
        if (fabView == null || !fabAdded) return;
        safeRemove(fabView);
        wm.addView(fabView, fabLp);
    }

    // ================================================================== menu

    private void toggleMenu() {
        if (menuView != null) { hideMenu(); return; }
        if (SystemClock.uptimeMillis() - lastMenuClose < 400) return;
        showMenu();
    }

    private void showMenu() {
        menuView = new LinearLayout(this) {
            @Override
            public boolean dispatchTouchEvent(MotionEvent e) {
                if (e.getActionMasked() == MotionEvent.ACTION_OUTSIDE) {
                    ui.post(() -> hideMenu());
                    return true;
                }
                return super.dispatchTouchEvent(e);
            }
        };
        menuView.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(6);
        menuView.setPadding(pad, pad, pad, pad);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xEE202124);
        bg.setCornerRadius(dp(18));
        menuView.setBackground(bg);

        addMenuItem(check(captureOn) + "Souris = toucher", () -> setCaptureMode(true));
        addMenuItem(check(!captureOn) + "Pointeur virtuel", () -> setCaptureMode(false));
        if (captureOn && Build.VERSION.SDK_INT >= 34) {
            addMenuItem(check(directMode) + "Mode direct (sans délai)", () -> setDirectMode(!directMode));
        }

        if (!captureOn) {
            addSeparator();
            boolean dragging = mode == Mode.DRAG_START || mode == Mode.DRAG_END;
            addMenuItem(check(mode == Mode.TAP) + "1 clic = 1 toucher", () -> setMode(Mode.TAP));
            addMenuItem(check(mode == Mode.LONG_PRESS) + "Appui long (prochain clic)", () -> setMode(Mode.LONG_PRESS));
            addMenuItem(check(dragging) + "Glisser-déposer (clic A puis B)", () -> setMode(Mode.DRAG_START));
            addMenuItem("      Recentrer le pointeur", this::recenterPointer);
        }

        addSeparator();
        addMenuItem("⌂   Accueil", () -> performGlobalAction(GLOBAL_ACTION_HOME));
        addMenuItem("←   Retour", () -> performGlobalAction(GLOBAL_ACTION_BACK));
        addSeparator();
        addMenuItem("      Arrêter le service", this::disableSelf);

        menuLp = overlayParams(WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT, true);
        menuLp.flags |= WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH;

        int spec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
        menuView.measure(spec, spec);
        int mw = menuView.getMeasuredWidth();
        int mh = menuView.getMeasuredHeight();
        int[] s = screenSize();
        boolean fabOnRight = fabLp.x + fabSize / 2 > s[0] / 2;
        int x = fabOnRight ? fabLp.x - mw - dp(8) : fabLp.x + fabSize + dp(8);
        menuLp.x = (int) clamp(x, 0, Math.max(0, s[0] - mw));
        menuLp.y = (int) clamp(fabLp.y, 0, Math.max(0, s[1] - mh));
        wm.addView(menuView, menuLp);
    }

    private void hideMenu() {
        if (menuView == null) return;
        safeRemove(menuView);
        menuView = null;
        lastMenuClose = SystemClock.uptimeMillis();
    }

    private static String check(boolean on) { return on ? "✓   " : "      "; }

    private void addMenuItem(String label, Runnable action) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(Color.WHITE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        t.setPadding(dp(14), dp(10), dp(18), dp(10));
        t.setMinWidth(dp(240));
        GradientDrawable pressed = new GradientDrawable();
        pressed.setColor(0x33FFFFFF);
        pressed.setCornerRadius(dp(12));
        StateListDrawable states = new StateListDrawable();
        states.addState(new int[]{android.R.attr.state_pressed}, pressed);
        t.setBackground(states);
        t.setClickable(true);
        t.setOnClickListener(v -> ui.post(() -> { hideMenu(); action.run(); }));
        menuView.addView(t);
    }

    private void addSeparator() {
        View sep = new View(this);
        sep.setBackgroundColor(0x33FFFFFF);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, Math.max(1, dp(1)));
        lp.setMargins(dp(10), dp(4), dp(10), dp(4));
        menuView.addView(sep, lp);
    }

    // ================================================================== utilitaires

    private WindowManager.LayoutParams overlayParams(int w, int h, boolean touchable) {
        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        if (!touchable) flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, flags, PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        return lp;
    }

    @SuppressWarnings("deprecation")
    private int[] screenSize() {
        if (Build.VERSION.SDK_INT >= 30) {
            Rect b = wm.getCurrentWindowMetrics().getBounds();
            return new int[]{b.width(), b.height()};
        }
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        return new int[]{dm.widthPixels, dm.heightPixels};
    }

    private void safeRemove(View v) {
        try { wm.removeView(v); } catch (Exception ignored) { }
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    /** Distingue un clic d'un déplacement (bouton flottant et poignée du pointeur). */
    private abstract class DragClick implements View.OnTouchListener {
        private float startRawX, startRawY;
        private boolean dragging;

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    startRawX = e.getRawX();
                    startRawY = e.getRawY();
                    dragging = false;
                    onStart();
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getRawX() - startRawX;
                    float dy = e.getRawY() - startRawY;
                    if (!dragging && Math.hypot(dx, dy) > touchSlop) dragging = true;
                    if (dragging) onDrag(dx, dy);
                    return true;
                }
                case MotionEvent.ACTION_UP:
                    if (!dragging) onClick();
                    onEnd();
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    onEnd();
                    return true;
                default:
                    return false;
            }
        }

        abstract void onStart();
        abstract void onDrag(float dx, float dy);
        abstract void onClick();
        void onEnd() { }
    }
}
