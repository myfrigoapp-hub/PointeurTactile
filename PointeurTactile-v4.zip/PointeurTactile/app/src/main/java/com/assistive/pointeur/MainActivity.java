package com.assistive.pointeur;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Typeface;
import android.hardware.input.InputManager;
import android.os.Build;
import android.view.InputDevice;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Écran d'accueil : état des autorisations et raccourcis vers les réglages. */
public class MainActivity extends Activity {

    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        int pad = dp(24);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText(R.string.app_name);
        title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        TextView intro = new TextView(this);
        intro.setText(R.string.intro);
        intro.setTextSize(15);
        intro.setPadding(0, dp(12), 0, 0);
        root.addView(intro);

        status = new TextView(this);
        status.setTextSize(16);
        status.setPadding(0, dp(20), 0, dp(12));
        root.addView(status);

        root.addView(button("1. Autoriser la superposition", v -> openOverlaySettings()));
        root.addView(button("2. Activer le service d'accessibilité",
                v -> open(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
        root.addView(button("Infos de l'appli (paramètres restreints)", v -> openAppDetails()));

        TextView help = new TextView(this);
        help.setText(R.string.help);
        help.setTextSize(13);
        help.setPadding(0, dp(16), 0, 0);
        root.addView(help);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean overlay = Settings.canDrawOverlays(this);
        boolean service = isServiceEnabled();
        status.setText((overlay ? "✅ " : "⬜ ") + "Superposition autorisée\n"
                + (service ? "✅ " : "⬜ ") + "Service d'accessibilité actif"
                + "\n" + (mousePresent() ? "🖱️ Souris détectée" : "🖱️ Aucune souris détectée")
                + "\n" + (Build.VERSION.SDK_INT >= 34
                        ? "Android " + Build.VERSION.RELEASE + " : mode direct disponible (sans délai)"
                        : "Android " + Build.VERSION.RELEASE + " : mode couche de capture")
                + (service ? "\n\nLe bouton flottant est affiché." : ""));
    }

    private boolean mousePresent() {
        InputManager im = (InputManager) getSystemService(INPUT_SERVICE);
        if (im == null) return false;
        for (int id : im.getInputDeviceIds()) {
            InputDevice d = im.getInputDevice(id);
            if (d != null && !d.isVirtual() && d.supportsSource(InputDevice.SOURCE_MOUSE)) return true;
        }
        return false;
    }

    private boolean isServiceEnabled() {
        String enabled = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) return false;
        ComponentName cn = new ComponentName(this, TouchService.class);
        String all = enabled.toLowerCase();
        return all.contains(cn.flattenToString().toLowerCase())
                || all.contains(cn.flattenToShortString().toLowerCase());
    }

    private void openOverlaySettings() {
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            openAppDetails();
        }
    }

    private void openAppDetails() {
        open(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + getPackageName())));
    }

    private void open(Intent intent) {
        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Écran de réglages indisponible sur cet appareil",
                    Toast.LENGTH_LONG).show();
        }
    }

    private Button button(String label, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(listener);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(8);
        b.setLayoutParams(lp);
        return b;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
