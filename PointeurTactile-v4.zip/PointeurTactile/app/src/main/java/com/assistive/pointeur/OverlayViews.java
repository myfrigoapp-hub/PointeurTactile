package com.assistive.pointeur;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

/** Vues dessinées à la main (aucune ressource image nécessaire). */
final class OverlayViews {

    private OverlayViews() { }

    static float dp(Context c, float v) {
        return v * c.getResources().getDisplayMetrics().density;
    }

    /** Viseur : son centre est le point exact où le toucher est envoyé. */
    static class CrossView extends View {
        private final Paint halo = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float d;

        CrossView(Context c, int color) {
            super(c);
            d = dp(c, 1);
            halo.setStyle(Paint.Style.STROKE);
            halo.setStrokeWidth(4.5f * d);
            halo.setColor(0xCCFFFFFF);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(2f * d);
            dot.setStyle(Paint.Style.FILL);
            setColor(color);
        }

        void setColor(int color) {
            stroke.setColor(color);
            dot.setColor(color);
            invalidate();
        }

        /** Retour visuel du toucher (alpha seulement, pour ne pas fausser la position). */
        void flash() {
            animate().cancel();
            setAlpha(0.2f);
            animate().alpha(1f).setDuration(180).start();
        }

        private void drawCross(Canvas c, Paint p, float cx, float cy, float r, float gap) {
            c.drawCircle(cx, cy, r, p);
            c.drawLine(cx, cy - r - 2 * d, cx, cy - gap, p);
            c.drawLine(cx, cy + gap, cx, cy + r + 2 * d, p);
            c.drawLine(cx - r - 2 * d, cy, cx - gap, cy, p);
            c.drawLine(cx + gap, cy, cx + r + 2 * d, cy, p);
        }

        @Override
        protected void onDraw(Canvas c) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            float r = Math.min(cx, cy) - 5f * d;
            float gap = 4f * d;
            drawCross(c, halo, cx, cy, r, gap);
            drawCross(c, stroke, cx, cy, r, gap);
            c.drawCircle(cx, cy, 1.8f * d, dot);
        }
    }

    /** Poignée ronde : on la fait glisser pour bouger le pointeur, on clique dessus pour toucher. */
    static class HandleView extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float d;
        private String label = "1:1";

        HandleView(Context c) {
            super(c);
            d = dp(c, 1);
            fill.setStyle(Paint.Style.FILL);
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeWidth(2f * d);
            ring.setColor(0xFFFFFFFF);
            text.setColor(0xFFFFFFFF);
            text.setTextAlign(Paint.Align.CENTER);
            text.setTextSize(11f * d);
            text.setTypeface(Typeface.DEFAULT_BOLD);
        }

        void setStyle(int color, String l) {
            fill.setColor((color & 0x00FFFFFF) | 0xCC000000);
            label = l;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            float r = Math.min(cx, cy) - 2f * d;
            c.drawCircle(cx, cy, r, fill);
            c.drawCircle(cx, cy, r, ring);
            float baseline = cy - (text.ascent() + text.descent()) / 2f;
            c.drawText(label, cx, baseline, text);
        }
    }

    /** Bouton flottant façon AssistiveTouch. */
    static class FabView extends View {
        private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint c1 = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint c2 = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint c3 = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();

        FabView(Context c) {
            super(c);
            bg.setColor(0xE6303030);
            c1.setColor(0x55FFFFFF);
            c2.setColor(0x99FFFFFF);
            c3.setColor(0xFFFFFFFF);
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            rect.set(0, 0, w, h);
            c.drawRoundRect(rect, w * 0.28f, h * 0.28f, bg);
            float cx = w / 2f, cy = h / 2f;
            c.drawCircle(cx, cy, w * 0.36f, c1);
            c.drawCircle(cx, cy, w * 0.27f, c2);
            c.drawCircle(cx, cy, w * 0.18f, c3);
        }
    }
}
