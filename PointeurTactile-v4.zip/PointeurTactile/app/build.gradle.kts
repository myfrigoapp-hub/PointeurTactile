plugins {
    id("com.android.application")
}

android {
    namespace = "com.assistive.pointeur"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.assistive.pointeur"
        minSdk = 26
        targetSdk = 34
        versionCode = 4
        versionName = "4.0"
    }

    // Clé de signature fixe : chaque nouvelle version peut remplacer l'ancienne
    // sans désinstallation (adb install -r, ou simple ouverture de l'APK sur la tablette).
    signingConfigs {
        create("fixe") {
            storeFile = file("signature.jks")
            storePassword = "pointeur"
            keyAlias = "pointeur"
            keyPassword = "pointeur"
        }
    }

    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("fixe") }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("fixe")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
