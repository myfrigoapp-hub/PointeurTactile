plugins {
    id("com.android.application")
}

android {
    namespace = "com.assistive.pointeur"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.assistive.pointeur"
        minSdk = 26          // continueStroke() pour le glisser-déposer
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
// Aucune dépendance : uniquement le framework Android, code 100 % Java
// => APK indépendant de l'architecture, fonctionne tel quel sur ARM64.
