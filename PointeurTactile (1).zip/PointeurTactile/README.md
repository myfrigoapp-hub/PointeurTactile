# Pointeur Tactile — AssistiveTouch pour Chromebook ARM

Bouton flottant + pointeur virtuel. **1 clic sur la poignée du pointeur = 1 toucher tactile unique**
(un `dispatchGesture` de 20 ms sur un point fixe, au centre du viseur).

## Obtenir l'APK sans rien installer (GitHub Actions)
1. Crée un dépôt GitHub (même privé) et envoie-y le contenu de ce dossier
   (bouton « Add file → Upload files » sur github.com suffit, en gardant le dossier `.github`).
2. Onglet **Actions** → workflow « Compiler l'APK » → il se lance tout seul (ou « Run workflow »).
3. À la fin (~3 min), télécharge l'artefact **PointeurTactile-apk** : il contient `app-debug.apk`.

## Ou avec Android Studio
Ouvrir le dossier → Build → Build APK(s). Fichier : `app/build/outputs/apk/debug/app-debug.apk`.

## Installer sur le Chromebook
1. Paramètres → Avancé → Développeurs → activer l'**environnement de développement Linux**.
2. Dans ses options : **Développer des applications Android** → activer le **débogage ADB** (redémarrage).
3. Copier l'APK dans « Fichiers Linux », puis dans le Terminal :
       sudo apt install -y adb
       adb connect 100.115.92.2:5555
       adb install app-debug.apk
   (accepter la demande d'autorisation ADB qui s'affiche à l'écran)

## Premier lancement
1. Ouvrir « Pointeur Tactile » → **Autoriser la superposition**.
2. **Activer le service d'accessibilité** « Pointeur Tactile (AssistiveTouch) ».
   Si l'option est grisée : Infos de l'appli → ⋮ → « Autoriser les paramètres restreints ».

## Utilisation
- **Mode « Souris = toucher » (défaut)** : chaque clic de souris devient un toucher de 20 ms à l'endroit du curseur.
  Clic maintenu = appui long de même durée · cliquer-glisser = glissé (rejoué au relâchement) ·
  molette = défilement · clic droit = Retour.
- **Mode « Pointeur virtuel »** (au choix dans le menu) :
- **Poignée ronde** (à côté du viseur) : glisser = déplacer le pointeur ; clic = toucher au centre du viseur.
- **Bouton flottant** : glisser = déplacer ; clic = menu.
- Menu : 1 clic = 1 toucher (défaut) · Appui long (prochain clic, 800 ms) ·
  Glisser-déposer (clic sur A, puis sur B) · Accueil · Retour · Masquer / recentrer le pointeur · Arrêter.
- Couleur de la poignée : bleu = 1:1, orange = appui long, vert = point A, rouge = point B.

## Limites connues sur ChromeOS
- Les touchers injectés n'agissent que sur les **applis Android**, pas sur Chrome, les applis Linux
  ni le bureau ChromeOS.
- « Accueil » renvoie à l'accueil Android, ce qui peut se traduire sur ChromeOS par une simple réduction.
- Si le bouton flottant ou le menu se trouve sous le viseur, c'est lui qui reçoit le toucher.
