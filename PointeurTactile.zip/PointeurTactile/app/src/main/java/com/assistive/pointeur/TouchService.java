package com.assistive.pointeur;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Reproduction d'AssistiveTouch :
 *  - un bouton flottant semi-transparent, déplaçable, qui ouvre un menu ;
 *  - un pointeur virtuel = un viseur NON cliquable (le point visé) + une poignée ronde à côté.
 *
 * Règle fondamentale : 1 clic sur la poignée = 1 seul dispatchGesture() d'un toucher de 20 ms
 * sur un point fixe, au centre exact du viseur. Le viseur laisse passer les touchers
 * (FLAG_NOT_TOUCHABLE), donc le toucher injecté atteint l'application en dessous.
 */
public class TouchService extends AccessibilityService {

    /** Toucher simple : 20 ms sur un point fixe. */
    private static final long TAP_MS = 20;
    private static final long LONG_PRESS_MS = 800;
    private static final long DRAG_HOLD_MS = 500;
    private static final long DRAG_MOVE_MS = 450;

    private static final int COLOR_TAP = 0xFF1E88E5;
    private static final int COLOR_LONG = 0xFFFB8C00;
    private static final int COLOR_DRAG_A = 0xFF43A047;
    private static final int COLOR_DRAG_B = 0xFFE53935;

    private enum Mode { TAP, LONG_PRESS, DRAG_START, DRAG_END }

    private WindowManager wm;
    private int touchSlop;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private OverlayViews.CrossView crossView;
    private OverlayViews.CrossView markerView;
    private OverlayViews.HandleView handleView;
    private OverlayViews.FabView fabView;
    private LinearLayout menuView;
    private WindowManager.LayoutParams crossLp, handleLp, markerLp, fabLp, menuLp;

    private int crossSize, handleSize, handleGap, fabSize;
    /** Point chaud du pointeur (coordonnées écran). */
    private float hotX, hotY;
    private Mode mode = Mode.TAP;
    private float dragStartX, dragStartY;
    private boolean pointerShown = false;
    private long lastMenuClose = 0;

    private final Runnable fadeFab = () -> {
        if (fabView != null) fabView.animate().alpha(0.45f).setDuration(250).start();
    };

    // ------------------------------------------------------------------ cycle de vie

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        touchSlop = ViewConfiguration.get(this).getScaledTouchSlop();
        crossSize = dp(32);
        handleSize = dp(40);
        handleGap = dp(16);
        fabSize = dp(56);

        int[] s = screenSize();
        hotX = s[0] / 2f;
        hotY = s[1] / 2f;

        // --- Pointeur : viseur (non cliquable) + poignée (cliquable)
        crossView = new OverlayViews.CrossView(this, COLOR_TAP);
        crossLp = overlayParams(crossSize, crossSize, false);

        handleView = new OverlayViews.HandleView(this);
        handleLp = overlayParams(handleSize, handleSize, true);
        handleView.setOnTouchListener(new DragClick() {
            float startX, startY;

            @Override void onStart() { startX = hotX; startY = hotY; }

            @Override void onDrag(float dx, float dy) {
                int[] sz = screenSize();
                hotX = clamp(startX + dx, 0, sz[0] - 1);
                hotY = clamp(startY + dy, 0, sz[1] - 1);
                layoutPointer();
            }

            @Override void onClick() { pointerClick(); }
        });
        showPointer();

        // --- Bouton flottant
        fabView = new OverlayViews.FabView(this);
        fabLp = overlayParams(fabSize, fabSize, true);
        fabLp.x = s[0] - fabSize - dp(16);
        fabLp.y = s[1] / 3;
        fabView.setAlpha(0.45f);
        fabView.setOnTouchListener(new DragClick() {
            int startX, startY;

            @Override void onStart() {
                ui.removeCallbacks(fadeFab);
                fabView.animate().cancel();
                fabView.setAlpha(1f);
                startX = fabLp.x;
                startY = fabLp.y;
            }

            @Override void onDrag(float dx, float dy) {
                hideMenu();
                int[] sz = screenSize();
                fabLp.x = (int) clamp(startX + dx, 0, sz[0] - fabSize);
                fabLp.y = (int) clamp(startY + dy, 0, sz[1] - fabSize);
                wm.updateViewLayout(fabView, fabLp);
            }

            @Override void onClick() { toggleMenu(); }

            @Override void onEnd() { ui.postDelayed(fadeFab, 1500); }
        });
        wm.addView(fabView, fabLp);

        setMode(Mode.TAP);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (wm == null) return;
        int[] s = screenSize();
        hotX = clamp(hotX, 0, s[0] - 1);
        hotY = clamp(hotY, 0, s[1] - 1);
        layoutPointer();
        if (fabView != null) {
            fabLp.x = (int) clamp(fabLp.x, 0, s[0] - fabSize);
            fabLp.y = (int) clamp(fabLp.y, 0, s[1] - fabSize);
            wm.updateViewLayout(fabView, fabLp);
        }
        hideMenu();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) { /* inutilisé */ }

    @Override
    public void onInterrupt() { /* inutilisé */ }

    @Override
    public void onDestroy() {
        removeAll();
        super.onDestroy();
    }

    private void removeAll() {
        if (wm == null) return;
        hideMenu();
        hidePointer();
        removeMarker();
        if (fabView != null) { safeRemove(fabView); fabView = null; }
    }

    // ------------------------------------------------------------------ actions du pointeur

    private void pointerClick() {
        float[] p = hotspotOnScreen();
        float x = p[0], y = p[1];
        switch (mode) {
            case TAP:
                press(x, y, TAP_MS);                 // 1 clic = 1 toucher
                break;
            case LONG_PRESS:
                press(x, y, LONG_PRESS_MS);          // ponctuel, puis retour au mode par défaut
                setMode(Mode.TAP);
                break;
            case DRAG_START:
                dragStartX = x;
                dragStartY = y;
                showMarker();
                setMode(Mode.DRAG_END);
                break;
            case DRAG_END:
                drag(dragStartX, dragStartY, x, y);
                setMode(Mode.TAP);
                break;
        }
    }

    /** Un seul geste : un trait sur un point fixe pendant {@code durationMs}. */
    private void press(float x, float y, long durationMs) {
        Path path = new Path();
        path.moveTo(Math.max(0f, x), Math.max(0f, y));
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, durationMs))
                .build();
        dispatchGesture(gesture, null, null);
        if (crossView != null) crossView.flash();
    }

    /** Glisser-déposer : maintien sur A, puis déplacement continu jusqu'à B sans relâcher. */
    private void drag(float sx, float sy, float ex, float ey) {
        sx = Math.max(0f, sx); sy = Math.max(0f, sy);
        ex = Math.max(0f, ex); ey = Math.max(0f, ey);

        Path hold = new Path();
        hold.moveTo(sx, sy);
        final GestureDescription.StrokeDescription first =
                new GestureDescription.StrokeDescription(hold, 0, DRAG_HOLD_MS, true);

        Path move = new Path();
        move.moveTo(sx, sy);
        move.lineTo(ex, ey);
        final GestureDescription.StrokeDescription second =
                first.continueStroke(move, 0, DRAG_MOVE_MS, false);

        dispatchGesture(new GestureDescription.Builder().addStroke(first).build(),
                new GestureResultCallback() {
                    @Override
                    public void onCompleted(GestureDescription gestureDescription) {
                        dispatchGesture(new GestureDescription.Builder().addStroke(second).build(),
                                null, null);
                    }
                }, null);
        if (crossView != null) crossView.flash();
    }

    private float[] hotspotOnScreen() {
        if (crossView != null && pointerShown && crossView.getWidth() > 0) {
            int[] loc = new int[2];
            crossView.getLocationOnScreen(loc);
            return new float[]{loc[0] + crossView.getWidth() / 2f, loc[1] + crossView.getHeight() / 2f};
        }
        return new float[]{hotX, hotY};
    }

    private void setMode(Mode m) {
        mode = m;
        if (m != Mode.DRAG_END) removeMarker();
        int color;
        String label;
        switch (m) {
            case LONG_PRESS: color = COLOR_LONG;   label = "long"; break;
            case DRAG_START: color = COLOR_DRAG_A; label = "A";    break;
            case DRAG_END:   color = COLOR_DRAG_B; label = "B";    break;
            default:         color = COLOR_TAP;    label = "1:1";  break;
        }
        if (handleView != null) handleView.setStyle(color, label);
        if (crossView != null) crossView.setColor(color);
    }

    // ------------------------------------------------------------------ pointeur : affichage

    private void layoutPointer() {
        int[] s = screenSize();
        crossLp.x = Math.round(hotX - crossSize / 2f);
        crossLp.y = Math.round(hotY - crossSize / 2f);

        // La poignée se place en bas à droite du viseur, et bascule près des bords.
        int hx = Math.round(hotX) + handleGap;
        int hy = Math.round(hotY) + handleGap;
        if (hx + handleSize > s[0]) hx = Math.round(hotX) - handleGap - handleSize;
        if (hy + handleSize > s[1]) hy = Math.round(hotY) - handleGap - handleSize;
        handleLp.x = hx;
        handleLp.y = hy;

        if (pointerShown) {
            wm.updateViewLayout(crossView, crossLp);
            wm.updateViewLayout(handleView, handleLp);
        }
    }

    private void showPointer() {
        if (pointerShown) return;
        layoutPointer();
        wm.addView(crossView, crossLp);
        wm.addView(handleView, handleLp);
        pointerShown = true;
    }

    private void hidePointer() {
        if (!pointerShown) return;
        safeRemove(crossView);
        safeRemove(handleView);
        pointerShown = false;
    }

    private void recenterPointer() {
        int[] s = screenSize();
        hotX = s[0] / 2f;
        hotY = s[1] / 2f;
        if (pointerShown) layoutPointer(); else showPointer();
    }

    private void showMarker() {
        removeMarker();
        markerView = new OverlayViews.CrossView(this, COLOR_DRAG_A);
        markerLp = overlayParams(crossSize, crossSize, false);
        markerLp.x = Math.round(hotX - crossSize / 2f);
        markerLp.y = Math.round(hotY - crossSize / 2f);
        wm.addView(markerView, markerLp);
    }

    private void removeMarker() {
        if (markerView != null) {
            safeRemove(markerView);
            markerView = null;
        }
    }

    // ------------------------------------------------------------------ menu

    private void toggleMenu() {
        if (menuView != null) { hideMenu(); return; }
        // Évite de rouvrir le menu juste après sa fermeture par un clic "extérieur" sur le bouton.
        if (SystemClock.uptimeMillis() - lastMenuClose < 400) return;
        showMenu();
    }

    private void showMenu() {
        menuView = new LinearLayout(this) {
            @Override
            public boolean dispatchTouchEvent(MotionEvent e) {
                if (e.getActionMasked() == MotionEvent.ACTION_OUTSIDE) {
                    ui.post(() -> hideMenu());
                    return true;
                }
                return super.dispatchTouchEvent(e);
            }
        };
        menuView.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(6);
        menuView.setPadding(pad, pad, pad, pad);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xEE202124);
        bg.setCornerRadius(dp(18));
        menuView.setBackground(bg);

        boolean dragging = mode == Mode.DRAG_START || mode == Mode.DRAG_END;
        addMenuItem(check(mode == Mode.TAP) + "1 clic = 1 toucher", () -> setMode(Mode.TAP));
        addMenuItem(check(mode == Mode.LONG_PRESS) + "Appui long (prochain clic)", () -> setMode(Mode.LONG_PRESS));
        addMenuItem(check(dragging) + "Glisser-déposer (clic A puis B)", () -> setMode(Mode.DRAG_START));
        addSeparator();
        addMenuItem("⌂   Accueil", () -> performGlobalAction(GLOBAL_ACTION_HOME));
        addMenuItem("←   Retour", () -> performGlobalAction(GLOBAL_ACTION_BACK));
        addSeparator();
        addMenuItem(pointerShown ? "Masquer le pointeur" : "Afficher le pointeur",
                () -> { if (pointerShown) hidePointer(); else showPointer(); });
        addMenuItem("Recentrer le pointeur", this::recenterPointer);
        addMenuItem("Arrêter le service", this::disableSelf);

        menuLp = overlayParams(WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT, true);
        menuLp.flags |= WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH;

        int spec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
        menuView.measure(spec, spec);
        int mw = menuView.getMeasuredWidth();
        int mh = menuView.getMeasuredHeight();
        int[] s = screenSize();
        boolean fabOnRight = fabLp.x + fabSize / 2 > s[0] / 2;
        int x = fabOnRight ? fabLp.x - mw - dp(8) : fabLp.x + fabSize + dp(8);
        menuLp.x = (int) clamp(x, 0, Math.max(0, s[0] - mw));
        menuLp.y = (int) clamp(fabLp.y, 0, Math.max(0, s[1] - mh));
        wm.addView(menuView, menuLp);
    }

    private void hideMenu() {
        if (menuView == null) return;
        safeRemove(menuView);
        menuView = null;
        lastMenuClose = SystemClock.uptimeMillis();
    }

    private static String check(boolean on) { return on ? "✓   " : "      "; }

    private void addMenuItem(String label, Runnable action) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(Color.WHITE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        t.setPadding(dp(14), dp(10), dp(18), dp(10));
        t.setMinWidth(dp(240));

        GradientDrawable pressed = new GradientDrawable();
        pressed.setColor(0x33FFFFFF);
        pressed.setCornerRadius(dp(12));
        StateListDrawable states = new StateListDrawable();
        states.addState(new int[]{android.R.attr.state_pressed}, pressed);
        t.setBackground(states);

        t.setClickable(true);
        t.setOnClickListener(v -> ui.post(() -> { hideMenu(); action.run(); }));
        menuView.addView(t);
    }

    private void addSeparator() {
        View sep = new View(this);
        sep.setBackgroundColor(0x33FFFFFF);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, Math.max(1, dp(1)));
        lp.setMargins(dp(10), dp(4), dp(10), dp(4));
        menuView.addView(sep, lp);
    }

    // ------------------------------------------------------------------ utilitaires

    /**
     * TYPE_ACCESSIBILITY_OVERLAY : s'affiche au-dessus des applis et, contrairement à
     * TYPE_APPLICATION_OVERLAY, n'est pas soumis au blocage des touchers "non fiables"
     * d'Android 12+, ce qui garantit que le toucher injecté traverse le viseur.
     */
    private WindowManager.LayoutParams overlayParams(int w, int h, boolean touchable) {
        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        if (!touchable) flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, flags, PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        return lp;
    }

    @SuppressWarnings("deprecation")
    private int[] screenSize() {
        if (Build.VERSION.SDK_INT >= 30) {
            Rect b = wm.getCurrentWindowMetrics().getBounds();
            return new int[]{b.width(), b.height()};
        }
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        return new int[]{dm.widthPixels, dm.heightPixels};
    }

    private void safeRemove(View v) {
        try { wm.removeView(v); } catch (Exception ignored) { }
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    /** Distingue un clic (pas de mouvement) d'un déplacement, à la souris comme au doigt. */
    private abstract class DragClick implements View.OnTouchListener {
        private float downX, downY;
        private boolean dragging;

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = e.getRawX();
                    downY = e.getRawY();
                    dragging = false;
                    onStart();
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getRawX() - downX;
                    float dy = e.getRawY() - downY;
                    if (!dragging && Math.hypot(dx, dy) > touchSlop) dragging = true;
                    if (dragging) onDrag(dx, dy);
                    return true;
                }
                case MotionEvent.ACTION_UP:
                    if (!dragging) onClick();
                    onEnd();
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    onEnd();
                    return true;
                default:
                    return false;
            }
        }

        abstract void onStart();
        abstract void onDrag(float dx, float dy);
        abstract void onClick();
        void onEnd() { }
    }
}
